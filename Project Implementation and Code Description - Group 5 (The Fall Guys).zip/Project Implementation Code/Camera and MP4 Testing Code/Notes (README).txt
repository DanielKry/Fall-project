These two codes are working prototypes. The mp4 code tests the model on external videos and the camera code tests our model on live camera footage by using our phones. 
If need be, we are happy to present these codes in person to show that all the functions work as stated that includes the droid camera and push over notification function.
