Download the gantt file and import the file via: 
https://www.onlinegantt.com/ 
